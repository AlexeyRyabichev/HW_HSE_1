﻿using System;

namespace Lib
{
    [Serializable]
    public class Programmer : Employee
    {
        public string ProjectName;
    }
}