﻿using System;

namespace Lib
{
    [Serializable]
    public class Manager : Employee
    {
        public int numberOfWorkers;
    }
}